#include<iostream>
using namespace std;
int main()
{
	int i; int my_size = 50; int count = 0;
	char option_selection = { 'b' };
	const int size = 100;
	int roll_no[size] = { 1, 2, 3, 4, 5,6,7,8,9,10,21,22,23,24,25,26,27,28,29,30,20,19,18,17,16,15,14,13,12,11,40,39,38,37,36,35,34,33,32,31,41,42,43,44,45,46,47,48,49,50 };
	float mids_marks[size] = { 22, 50, 40.5, 31, 42, 45, 50, 29.5, 32, 12, 8.5, 32, 21.5, 46, 8, 19.5, 16, 32, 44.5, 20, 21.5, 22, 23, 55, 55.5, 25, 14, 13.4, 15.5, 30, 31, 32.5, 33.6, 34, 35, 45, 50, 12, 8, 9, 10, 11, 23, 24, 25, 26, 12, 24.5, 34, 35 };
	float final_marks[size] = { 55.5, 56, 57.5, 58, 59, 88, 67, 54, 54, 33, 22, 89, 91, 67, 74, 46, 88.5, 12.4, 25.6, 55, 49, 77.5, 32, 14, 98, 87, 66.5, 23, 55.5, 66, 72.5, 65, 43.5, 66.6, 98.7, 12, 89, 64.7, 87.6, 67, 54, 33.5, 76.5, 65, 99, 13, 98.5, 76, 88, 67.5 };
	int class_of_student[size] = { 1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 6, 2, 7, 1, 7, 5, 3, 4, 8, 3, 4, 2, 1, 5, 3, 1, 3, 6, 7, 8, 5, 4, 3, 4, 2, 6, 7, 8, 2, 1, 6, 5, 4, 3, 8, 8, 2, 1, 4 };
	char grades[size] = {};
	int my_roll_no[size] = {};
	float my_mids_marks[size] = {};
	float my_final_marks[size] = {};
	int my_class_of_students[size] = {};
	char my_grades[size] = {};
	int temp = 0; float temp1 = 0; int deleted_roll_no; int x_marks = 0; char x_grade = {}; int marks = 0;
	for (i = 0; i < my_size; i++)
	{
		if (final_marks[i] < 50)
		{
			grades[i] = 'F';
		}
		else if (final_marks[i] >= 50 && final_marks[i] <= 59)
		{
			grades[i] = 'D';
		}
		else if (final_marks[i] >= 60 && final_marks[i] <= 72)
		{
			grades[i] = 'C';
		}
		else if (final_marks[i] >= 73 && final_marks[i] <= 85)
		{
			grades[i] = 'B';
		}
		else if (final_marks[i] >= 86)
		{
			grades[i] = 'A';
		}
	}
	for (i = 0; i < my_size; i++)
	{
		my_roll_no[i] = roll_no[i];
		my_mids_marks[i] = mids_marks[i];
		my_final_marks[i] = final_marks[i];
		my_class_of_students[i] = class_of_student[i];
		my_grades[i] = grades[i];
	}
	for (i = 0; i < my_size; i++)
	{
		cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
	}

	while (option_selection == 'a' || option_selection == 'b' || option_selection == 'c' || option_selection == 'd' || option_selection == 'z' || option_selection == 'f' || option_selection == 'g' || option_selection == 'h' || option_selection == 'i' || option_selection == 'j' || option_selection == 'k' || option_selection == 'l' || option_selection == 'm' || option_selection == 'n' || option_selection == 'o' || option_selection == 'p' || option_selection == 'q' || option_selection == 'r')
	{

		if (option_selection == 'e' || option_selection == 'E')
		{
			break;
		}
		else
		{
			cout << "*MENU**" << endl;
			cout << "a.Sort and display all the records roll number wise in ascending order:" << endl;
			cout << "b.Sort and display all the records roll number wise in descending order:" << endl;
			cout << "c.Sort and display all records in ascending order based on marks in Midterm:" << endl;
			cout << "d.Sort and display all records in descending order based on marks in Midterm: " << endl;
			cout << "z.Sort and display all records in ascending order based on marks in Final: " << endl;
			cout << "f.Sort and display all records in descending order based on marks in Final: " << endl;
			cout << "g.Sort and display all records in ascending order based on Grade: " << endl;
			cout << "h.Sort and display all records in descending order based on Grade: " << endl;
			cout << "i.Add a new entry of a student:" << endl;
			cout << "j.Delete a student record based on his roll number:" << endl;
			cout << "k.Display record of all the students greater than X marks in final exam (in descending order with respect to marks obtained in final exam). The value of X will be entered by the user: " << endl;
			cout << "l.Display record of all the students greater than X marks in final exam (in ascending order with respect to marks obtained in final exam). The value of X will be entered by the user:" << endl;
			cout << "m.Display record of all the students less than or equal to X marks in final exam (in descending order with respect to marks obtained in final exam). The value of X will be entered by the user:" << endl;
			cout << "n.Display record of all the students less than or equal to X marks in final exam (in ascending order with respect to marks obtained in final exam). The value of X will be entered by the user:" << endl;
			cout << "o.Display record of all the students greater than X grade (in descending order with respect to grade). The value of X (character) will be entered by the user:" << endl;
			cout << "p.Display record of all the students greater than X grade (in ascending order with respect to grade). The value of X (character) will be entered by the user:" << endl;
			cout << "q.Display record of all the students less than or equal to X grade (in descending order with respect to grade). The value of X (character) will be entered by the user:" << endl;
			cout << "r.Display record of all the students less than or equal to X grade (in ascending order with respect to grade). The value of X (character) will be entered by the user:" << endl;
			cout << "PRESS 'e'or 'E' for exit" << endl;
			cout << "enter option:"; cin >> option_selection;
			if (option_selection != 'e' && option_selection != 'E' && option_selection != 'a' && option_selection != 'b' && option_selection != 'c' && option_selection != 'd' && option_selection != 'z' && option_selection != 'f' && option_selection != 'g' && option_selection != 'h' && option_selection != 'i' && option_selection != 'j' && option_selection != 'k' && option_selection != 'l' && option_selection != 'm' && option_selection != 'n' && option_selection != 'o' && option_selection != 'p' && option_selection != 'q'&&option_selection != 'r')
			{
				cout << "Enter a valid option:" << endl;
				cin >> option_selection;
			}
		}if (option_selection == 'a')
		{
			for (int j = 0; j < my_size; j++)
			{
				for (i = 0; i<my_size - 1; i++)
				{
					if (my_roll_no[i] > my_roll_no[i + 1])
					{
						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;
					}
				}
			}
			for (i = 0; i < my_size; i++)
			{
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
			}
		}
		if (option_selection == 'b')
		{
			for (int j = 0; j < my_size; j++)
			{
				for (i = 0; i<my_size - 1; i++)
				{
					if (my_roll_no[i] < my_roll_no[i + 1])
					{
						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;

						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] =my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;
					}
				}
			}
			for (i = 0; i < my_size; i++)
			{
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" <<my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
			}
		}
		else if (option_selection == 'c')
		{
			for (int j = 0; j <my_size; j++)
			{
				for (i = 0; i<my_size - 1; i++)
				{
					if (my_mids_marks[i] > my_mids_marks[i + 1])
					{
						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] =my_roll_no[i];
						my_roll_no[i] = temp;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp =my_grades[i + 1];
						my_grades[i + 1] =my_grades[i];
						my_grades[i] = temp;


					}
				}
			}
			for (i = 0; i <my_size; i++){
			
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" <<my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
			}

		}

		else if (option_selection == 'd')
		{
			for (int j = 0; j < my_size; j++)
			{
				for (i = 0; i<my_size - 1; i++)
				{
					if (my_mids_marks[i] < my_mids_marks[i + 1])
					{
						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] =my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp =my_class_of_students[i + 1];
						my_class_of_students[i + 1] =my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] =my_roll_no[i];
						my_roll_no[i] = temp;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;


					}
				}
			}
			for (i = 0; i < my_size; i++)
			{
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" <<my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" <<my_class_of_students[i] << "  " << "Grades:" <<my_grades[i] << endl;
			}
		}
		else if (option_selection == 'z')
		{
			for (int j = 0; j < my_size; j++)
			{
				for (i = 0; i<my_size - 1; i++)
				{
					if (my_final_marks[i] > my_final_marks[i + 1])
					{
						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;


					}
				}
			}
			for (i = 0; i < my_size; i++)
			{
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
			}
		}
		else if (option_selection == 'f')
		{
			for (int j = 0; j < my_size; j++)
			{
				for (i = 0; i<my_size - 1; i++)
				{
					if (my_final_marks[i] < my_final_marks[i + 1])
					{
						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp =my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] =my_grades[i];
						my_grades[i] = temp;


					}
				}
			}
			for (i = 0; i <my_size; i++)
			{
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" <<my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" <<my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
			}
		}
		else if (option_selection == 'g')
		{
			for (int j = 0; j < my_size; j++)
			{
				for (i = 0; i<my_size - 1; i++)
				{
					if (my_final_marks[i] > my_final_marks[i + 1])
					{
						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp =my_grades[i + 1];
						my_grades[i + 1] =my_grades[i];
						my_grades[i] = temp;


					}
				}
			}
			for (i = 0; i < my_size; i++)
			{
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" <<my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" <<my_grades[i] << endl;
			}
		}
		else if (option_selection == 'h')
		{
			for (int j = 0; j < my_size; j++)
			{
				for (i = 0; i<my_size - 1; i++)
				{
					if (my_final_marks[i] < my_final_marks[i + 1])
					{
						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp1 =my_mids_marks[i + 1];
						my_mids_marks[i + 1] =my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp =my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;


					}
				}
			}for (i = 0; i < my_size; i++)
			{
				cout << "roll no:" <<my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
			}

		}
		else if (option_selection == 'i')
		{
			my_size++;
			do{
				cout << "Enter a roll no:" << endl;
				cin >> my_roll_no[my_size];
				do
				{
					count = 0;
					for (i = 0; i < my_size; i++)
					{
						if (my_roll_no[size] ==my_roll_no[i])
						{
							count++;
						}
					}
					if (count>0)
					{
						cout << "Plz try any other roll no:" << endl;
						cin >> my_roll_no[my_size];
					}
				} while (count != 0);
				if (my_roll_no[my_size] < 1)
				{
					cout << "Plz enter a positive no: " << endl;
					cin >> my_roll_no[my_size];
				}
				else if (my_roll_no[my_size]>2147483627)
				{
					cout << "Plz enter smaller roll no:" << endl;
					cin >>my_roll_no[my_size];
				}
			} while (my_roll_no[my_size]<1 || my_roll_no[my_size]>2147483627);
			do
			{
				cout << "Eenter marks obtain in mid term exam: " << endl;
				cin >> my_mids_marks[my_size];
				if (my_mids_marks[my_size] < 0)
				{
					cout << "Plz enter a positive interger:" << endl;
					cin >> my_mids_marks[my_size];
				}
				else if (my_mids_marks[my_size]>50)
				{
					cout << "PLZ! Enter a marks smaller then 50" << endl;
					cin >> my_mids_marks[my_size];
				}
			} while (my_mids_marks[my_size] < 0 || my_mids_marks[my_size]>50);
			do
			{
				cout << "Enter marks obtrained in final term:" << endl;
				cin >> my_final_marks[my_size];
				if (my_final_marks[my_size] < 0)
				{
					cout << "PLZ! enter a positive number :" << endl;
					cin >>my_final_marks[my_size];
				}
				else if (my_final_marks[my_size]>100)
				{
					cout << "PLZ!enter a number smaller then 100:" << endl;
					cin >> final_marks[my_size];
				}
			} while (my_final_marks[my_size]<0 || my_final_marks[my_size]>100);
			if (final_marks[my_size] <50)
			{
				grades[my_size] = 'F';
			}
			else if (final_marks[my_size] >= 50 && final_marks[my_size] <= 59)
			{
				grades[my_size] = 'D';
			}
			else if (final_marks[my_size] >= 60 && final_marks[my_size] <= 72)
			{
				grades[my_size] = 'C';
			}
			else if (final_marks[my_size] >= 73 && final_marks[my_size] <= 85)
			{
				grades[my_size] = 'B';
			}
			else if (final_marks[my_size] >= 86)
			{
				grades[my_size] = 'A';
			}do{
				cout << "Enter the class :" << endl;
				cin >>my_class_of_students[my_size];
				if (my_class_of_students[my_size]<1 || my_class_of_students[my_size]>8)
				{
					cout << "plz enter the class of a student which is less then '8'and greater then '0'" << endl;
					cin >> my_class_of_students[my_size];
				}
			} while (my_class_of_students[my_size]<1 || my_class_of_students[my_size]>8);

			for (i = 0; i <=my_size; i++)
			{
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" <<my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" <<my_grades[i] << endl;
			}
		}
		else if (option_selection == 'j')
		{
			int x = 0;
			do{
				count = 0;
				cout << "Enter the roll which uh want to delete " << endl;
				cin >> deleted_roll_no;
				for (i = 0; i <= size; i++)
				{
					if (deleted_roll_no == my_roll_no[i])
					{
						count++;
					}
				}
				if (count == 0)
				{
					cout << "not available in record" << endl;
				}
				else if (count != 0)
				{
					for (i = 0; i <= my_size; i++)
					{
						if (my_roll_no[i] == deleted_roll_no)
						{
							my_roll_no[i] = 0;
							for (int k = 0; k < my_size; k++)
							{
								for (x = 0; x <=my_size; x++)
								{
									if (my_roll_no[x] == 0)
									{
										temp = my_roll_no[x + 1];
										my_roll_no[x + 1] = my_roll_no[x];
										my_roll_no[x] = temp;

										temp = my_class_of_students[x + 1];
										my_class_of_students[x + 1] =my_class_of_students[x];
										my_class_of_students[x] = temp;

										temp1 =my_mids_marks[x + 1];
										my_mids_marks[x + 1] =my_mids_marks[x];
										my_mids_marks[x] = temp1;

										temp = my_grades[x + 1];
										my_grades[x + 1] = my_grades[x];
										my_grades[x] = temp;


										temp1 = my_final_marks[x + 1];
										my_final_marks[x + 1] = my_final_marks[x];
										my_final_marks[x] = temp1;
									}

								}
							}
						}
					}
				}
			} while (count == 0);
			my_size--;
			for (i = 0; i <= my_size; i++)
			{
				cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" <<my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
			}
		}
		else if (option_selection == 'k')
		{
			do
			{
				cout << "Plz!enter X marks" << endl;
				cin >> x_marks;
				if (x_marks<0 || x_marks>100)
				{
					cout << "PLZ!enter marks greater theno and less then 100" << endl;
				}
			} while (x_marks<0 || x_marks>100);
			for (int x = 0; x < my_size; x++)
			{
				for (int i = 0; i <my_size; i++)
				{
					if (my_final_marks[i]<my_final_marks[i + 1])
					{
						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 =my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] =my_grades[i];
						my_grades[i] = temp;
					}
				}
			}for (i = 0; i <my_size; i++)
			{
				if (my_final_marks[i]>x_marks)
				{

					{
						cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" <<my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
					}
				}
			}
		}
		else if (option_selection == 'l')
		{
			do
			{
				cout << "Plz!enter X marks" << endl;
				cin >> x_marks;
				if (x_marks<0 || x_marks>100)
				{
					cout << "PLZ!enter marks greater theno and less then 100" << endl;
				}
			} while (x_marks<0 || x_marks>100);
			for (int x = 0; x < my_size; x++)
			{
				for (int i = 0; i < my_size; i++)
				{
					if (my_final_marks[i]>my_final_marks[i + 1])
					{
						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;
					}
				}
			}for (i = 0; i < my_size; i++)
			{
				if (my_final_marks[i]>x_marks)
				{

					{
						cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" <<my_grades[i] << endl;
					}
				}
			}
		}
		else if (option_selection == 'm')
		{
			do
			{
				cout << "Plz!enter X marks" << endl;
				cin >> x_marks;
				if (x_marks<0 || x_marks>100)
				{
					cout << "PLZ!enter marks greater theno and less then 100" << endl;
				}
			} while (x_marks<0 || x_marks>100);
			for (int x = 0; x < my_size; x++)
			{
				for (int i = 0; i < my_size; i++)
				{
					if (my_final_marks[i]<my_final_marks[i + 1])
					{
						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] =my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 =my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;
					}
				}
			}for (i = 0; i < my_size; i++)
			{
				if (my_final_marks[i] <= x_marks)
				{

					{
						cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
					}
				}
			}
		}
		else if (option_selection == 'n')
		{
			do
			{
				cout << "Plz!enter X marks" << endl;
				cin >> x_marks;
				if (x_marks<0 || x_marks>100)
				{
					cout << "PLZ!enter marks greater theno and less then 100" << endl;
				}
			} while (x_marks<0 || x_marks>100);
			for (int x = 0; x < my_size; x++)
			{
				for (int i = 0; i < my_size; i++)
				{
					if (my_final_marks[i]>my_final_marks[i + 1])
					{
						temp = my_roll_no[i + 1];
					    my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;


						temp1 = my_mids_marks[i + 1];
				     	my_mids_marks[i + 1] =my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;
					}
				}
			}for (i = 0; i < my_size; i++)
			{
				if (my_final_marks[i] <= x_marks)
				{

					{
						cout << "roll no:" << my_roll_no[i] << "  " << "mids marks:" << my_mids_marks[i] << "  " << "final marks:" << my_final_marks[i] << "  " << "class:" << my_class_of_students[i] << "  " << "Grades:" << my_grades[i] << endl;
					}
				}
			}
		}
		else if (option_selection == 'o')
		{

			do
			{
				cout << "enter X grade" << endl;
				cin >> x_grade;
				if (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D')
				{
					cout << "please enter valid grade" << endl;
				}
			} while (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D');
			for (int j = 0; j <= size; j++)
			{
				for (i = 0; i <my_size - 1; i++)
				{
					if (my_final_marks[i] < my_final_marks[i + 1])
					{
						temp =my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;

						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] = my_grades[i];
						my_grades[i] = temp;
					}
				}
			}

			if (x_grade == 'F')
			{
				marks = 49;
			}
			else if (x_grade == 'D')
			{
				marks = 59;
			}
			else if (x_grade == 'C')
			{
				marks = 72;
			}
			else if (x_grade == 'B')
			{
				marks = 85;
			}
			else if (x_grade == 'A')
			{
				marks = 100;
			}
			for (i = 0; i <my_size; i++)
			{
				if (my_final_marks[i] > marks)
				{
					cout << "ROLL NUM : " <<my_roll_no[i] << "      MID MARKS : " << my_mids_marks[i] << "      FINAL MARKS : " << my_final_marks[i] << "      CLASS : " <<my_class_of_students[i] << "      GRADE : " << my_grades[i] << endl;
				}

			}
		}
		else if (option_selection == 'p')
		{
			do
			{
				cout << "enter X grade" << endl;
				cin >> x_grade;
				if (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D')
				{
					cout << "please enter valid grade" << endl;
				}
			} while (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D');
			for (int j = 0; j <= size; j++)
			{
				for (i = 0; i< my_size - 1; i++)
				{
					if (my_final_marks[i] >my_final_marks[i + 1])
					{
						temp =my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;

						temp1 =my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] =my_grades[i];
						my_grades[i] = temp;
					}
				}
			}

			if (x_grade == 'F')
			{
				marks = 49;
			}
			else if (x_grade == 'D')
			{
				marks = 59;
			}
			else if (x_grade == 'C')
			{
				marks = 72;
			}
			else if (x_grade == 'B')
			{
				marks = 85;
			}
			else if (x_grade == 'A')
			{
				marks = 100;
			}
			for (i = 0; i < my_size; i++)
			{
				if (my_final_marks[i] > marks)
				{
					cout << "ROLL NUM : " <<my_roll_no[i] << "      MID MARKS : " << my_mids_marks[i] << "      FINAL MARKS : " << my_final_marks[i] << "      CLASS : " << my_class_of_students[i] << "      GRADE : " << my_grades[i] << endl;
				}
			}
		}
		else if (option_selection == 'q')
		{
			do
			{
				cout << "enter X grade" << endl;
				cin >> x_grade;
				if (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D')
				{
					cout << "please enter valid grade" << endl;
				}
			} while (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D');
			for (int j = 0; j <= size; j++)
			{
				for (i = 0; i <my_size - 1; i++)
				{
					if (my_final_marks[i] < my_final_marks[i + 1])
					{
						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp = my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;

						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 =my_final_marks[i + 1];
						my_final_marks[i + 1] =my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] =my_grades[i];
						my_grades[i] = temp;
					}
				}
			}

			if (x_grade == 'F')
			{
				marks = 49;
			}
			else if (x_grade == 'D')
			{
				marks = 59;
			}
			else if (x_grade == 'C')
			{
				marks = 72;
			}
			else if (x_grade == 'B')
			{
				marks = 85;
			}
			else if (x_grade == 'A')
			{
				marks = 100;
			}
			for (i = 0; i < my_size; i++)
			{
				if (my_final_marks[i] <= marks)
				{
					cout << "ROLL NUM : " <<my_roll_no[i] << "      MID MARKS : " << my_mids_marks[i] << "      FINAL MARKS : " << my_final_marks[i] << "      CLASS : " << my_class_of_students[i] << "      GRADE : " << my_grades[i] << endl;
				}
			}
		}
		else if (option_selection == 'r')
		{
			do
			{
				cout << "enter X grade" << endl;
				cin >> x_grade;
				if (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D')
				{
					cout << "please enter valid grade" << endl;
				}
			} while (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D');
			for (int j = 0; j <= size; j++)
			{
				for (i = 0; i <my_size - 1; i++)
				{
					if (my_final_marks[i] > my_final_marks[i + 1])
					{
						temp = my_roll_no[i + 1];
						my_roll_no[i + 1] = my_roll_no[i];
						my_roll_no[i] = temp;

						temp =my_class_of_students[i + 1];
						my_class_of_students[i + 1] = my_class_of_students[i];
						my_class_of_students[i] = temp;

						temp1 = my_mids_marks[i + 1];
						my_mids_marks[i + 1] = my_mids_marks[i];
						my_mids_marks[i] = temp1;

						temp1 = my_final_marks[i + 1];
						my_final_marks[i + 1] = my_final_marks[i];
						my_final_marks[i] = temp1;

						temp = my_grades[i + 1];
						my_grades[i + 1] =my_grades[i];
						my_grades[i] = temp;
					}
				}
			}

			if (x_grade == 'F')
			{
				marks = 49;
			}
			else if (x_grade == 'D')
			{
				marks = 59;
			}
			else if (x_grade == 'C')
			{
				marks = 72;
			}
			else if (x_grade == 'B')
			{
				marks = 85;
			}
			else if (x_grade == 'A')
			{
				marks = 100;
			}
			for (i = 0; i < my_size; i++)
			{
				if (my_final_marks[i] <= marks)
				{
					cout << "ROLL NUM : " << my_roll_no[i] << "      MID MARKS : " << my_mids_marks[i] << "      FINAL MARKS : " << my_final_marks[i] << "      CLASS : " << my_class_of_students[i] << "      GRADE : " <<my_grades[i] << endl;
				}
			}
		}



	}
	return 0;
}