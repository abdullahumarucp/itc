#include<iostream>
using namespace std;
int main(){
	int option;
	cout << "Enter the number between 1 to 4: ";
	cin >> option;
	if (option < 1 || option > 4){
		cout << "you enter wrong input: " << endl;
	}

	if (option == 1)
	{
		int arr[10];
		int temp[10];
		int num;
		cout << "Enter the values in array" << endl;
		for (int i = 0; i < 10; i++)
		{
			cin >> arr[i];
		}
		cout << "Enter a number to find location: ";
		cin >> num;
		for (int i = 0; i < 10; i++)
		{
			if (arr[i] == num){
				temp[i] = i;
				cout << arr[i] << " is in the index of " << temp[i] << endl;
			}
		}
	}
	else if (option == 2)
	{
		int arr[10];
		int num;
		int first = 0;
		int last = 9;
		int middle = (first + last) / 2;
		cout << "Enter the value in an array (in ascending order): ";
		for (int i = 0; i < 10; i++){
			cin >> arr[i];
		}
		cout << "Enter a number to find location: ";
		cin >> num;
		while (first <= last)
		{
			if (arr[middle] < num)
				first = middle + 1;
			else if (arr[middle] == num)
			{
				cout << num << " is on the index of: " << middle+1;
				break;
			}
			else
				last = middle - 1;
			middle = (first + last) / 2;
		}
		if (first > last)
			cout << num << " is not found in given Array";

		cout << endl;
	}
	else if (option == 3)
	{
		int i = 0;
		char arr[] = {"hello sir"};
		int size = 0;
		for (int i = 0; arr[i] != '\0'; i++){
			size++;
		}
		for (int i = size; i >= 0; i--)
		{
			cout << arr[i];
		}
		cout << endl;
	}
	else if (option == 4){
		int arr[10];
		int temp;
		cout << "enter an array to sort in decending order : ";
		for (int i = 0; i < 10; i++){
			cin >> arr[i];
		}
		for (int i = 0; i < 10; i++){
			for (int j = 0; j < 10; j++){
				if (arr[i]>arr[j]){

					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		cout << "sorted array is : ";
		for (int i = 0; i < 10; i++)
		{
			cout << arr[i];
		}
	}

	system("pause");
	return 0;
}