#include<iostream>
using namespace std;
int main()
{
	int a, b, s, temp;
	cout << "enter nominator";
	cin >> a;
	cout << "enter denominator";
	cin >> b;
	int n, k;
	n = a;
	k = b;

	a = abs(a);
	b = abs(b);
	if (b > a)
	{
		temp = a;
		a = b;
		b = temp;
	}
	while ((s = a%b) != 0)
	{
		a = b;
		b = s;
	}
	
	
	if (n < 0 && k < 0)
	{
		n = abs(n);
		k = abs(k);
	}
	cout << "the nominator is = " << n / b << "the denominator is = " << k / b << endl;
	return 0;
}