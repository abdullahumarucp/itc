#include <iostream>
using namespace std;

int main()
{
	int x, y, i, HCF;

	cout << "Enter two integer values=" << endl;
	cin >> x >> y;

	for (i = 1; i <= x && i <= y; i++)
	{
		if (x % i == 0 && y % i == 0)
			HCF = i;
	}

	cout << "HCF of " << x << " and " << y << " is= " << HCF << endl;

	return 0;
}



/* 
               "ALGORITHM"
#1 Start the code.
#2 Enter two integers values (x,y).
#3 Using for loop in code. "syntax= for (i = 1; i <= x && i <= y; i++)"
#4 Use if inside for loop for taking mode.
#5 Print HCF of integers input by user abdullah.
#6 End code.
*/