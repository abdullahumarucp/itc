#include<iostream>
using namespace std;
int a[100];
int main()
{
	
	int max, min, i, n = 0;
	cout << "Enter the Elements" << endl;
	cin >> n;
	  
	for (i = 1; i <= n; i++)
	{
		cin >> a[i];
	}
	while (n != 0)
		break;



		max = a[0];


		for (i = 0; i < 100; i++)
		{
			if (max < a[i])
			{
				max = a[i];
			}
		}
		cout << "Maximum Value is " << max << endl;
		min = a[0];
		for (i = 0; i<100; i++)
		{
			if (min>a[i])
			{
				min = a[i];
			}
		}
		cout << "Minimum value is " << min << endl;

	return 0;
}