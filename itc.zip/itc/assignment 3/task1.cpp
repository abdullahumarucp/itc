#include<iostream>
using namespace std;
int main()
{
	int amount1 = 0, amount2 = 1;
	int num;
	int next_amount = 0;
	cout << "enter the number of term which u wanna see: " << endl;
	cin >> num;
	num -= 2;
	int i = 1;
	while ( i <= num )//using while loop.
	{
		i++,
		next_amount = amount1 + amount2;//using sum.
		amount1 = amount2;
		amount2 = next_amount;

	}
	cout << next_amount;
	return 0;
}