#include<iostream>
using namespace std;
int main()
{
	int hotel, floor, floors;
	int rooms = {};
	int occupied_rooms = {};
	int  unoccupied_rooms = {};
	int occupation_rate = {};
	cout << "number of floors are=" << endl;
	cin >> floors;
	do{
		cout << "number of floors=" << endl;
		switch (floors)
		{
		case1:
			cout << "there are 4 rooms in first floor and all are reserved" << endl;
			cin >> occupied_rooms;
			cin >> unoccupied_rooms;
			break;
		}
		switch (floors)
		{
		case2:
			cout << "there are 5 rooms in first floor and all are reserved" << endl;
			cin >> occupied_rooms;
			cin >> unoccupied_rooms;
			break;
		}
		switch (floors)
		{
		case3:
			cout << "there are 4 rooms in first floor and all are reserved" << endl;
			cin >> occupied_rooms;
			cin >> unoccupied_rooms;
			break;

		default:
				cout << endl;
		}
	}
		while (occupied_rooms < 0);
		rooms += occupied_rooms;
		unoccupied_rooms += rooms - occupied_rooms;
	}
int rooms;
float occupation_rate = rooms * 14;




	return 0;
}