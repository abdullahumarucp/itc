#include<iostream>
using namespace std;
int main()
{


	int i;
	int k;
	char option;
	const int entries = 50;
	char option_selection = 'a';
	int size = 49;
	int temp;
	float temp1;
	char temp2;
	int count = 0;
	bool flag = false;
	int delete_roll_num;
	int deletion_array[100] = {};
	float x_marks;
	char x_grade;
	float marks;


	//arrays
	const int roll_num_size = 100;
	int roll_num[roll_num_size] = { 69, 2, 3, 4, 5, 6, 7, 8, 9, 56, 95, 12, 13, 87, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50 };

	const int mid_marks_size = 100;
	float mid_marks[mid_marks_size] = { 12.0, 44.7, 28.1, 23.2, 8.3, 4.4, 34.5, 43.6, 23.7, 23.8, 50, 24.0, 32.2, 43.3, 42.4, 47.4, 12.5, 23.6, 34.7, 39.9, 47.1, 26.2, 19.4, 24.7, 49.8, 24.8, 47.2, 39.1, 29.1, 12.2, 50, 23.7, 24.9, 24.8, 25.3, 49.1, 33.2, 23.6, 36.8, 36.9, 36.1, 21.1, 27.3, 28.2, 39.1, 47.5, 49.7, 36.1, 27.1, 39.1 };

	const int final_marks_size = 100;
	float final_marks[final_marks_size] = { 67.9, 78.4, 37.7, 95, 8, 58, 89.9, 33.9, 56.3, 32.1, 57.9, 35.1, 24.9, 68.9, 24.7, 98.1, 46.9, 59.8, 92, 95, 3, 42, 15, 27, 87.0, 5.5, 87.8, 45.9, 43.0, 89.9, 34.1, 86.9, 23.8, 12.7, 89.8, 23.6, 67.3, 12.1, 85.6, 72.1, 8.8, 93.8, 82.9, 58.1, 79.9, 56.8, 12.7, 83.7, 56.2, 19.4 };

	const int class_size = 100;
	int class_of_student[class_size] = { 2, 5, 2, 7, 4, 7, 3, 7, 4, 6, 2, 7, 8, 3, 1, 5, 6, 3, 8, 1, 6, 3, 7, 3, 4, 6, 5, 2, 1, 6, 8, 2, 2, 8, 4, 6, 2, 7, 4, 5, 1, 2, 1, 1, 8, 6, 8, 2, 7, 4 };


	//Grade calculation
	const int grade_size = 100;
	char grade[grade_size] = {};

	for (i = 0; i <= size; i++)
	{
		if (final_marks[i] >= 86 && final_marks[i] <= 100)
		{
			grade[i] = 'A';
		}
		else if (final_marks[i] >= 73 && final_marks[i] < 86)
		{
			grade[i] = 'B';
		}
		else if (final_marks[i] >= 60 && final_marks[i] < 73)
		{
			grade[i] = 'C';
		}
		else if (final_marks[i] >= 50 && final_marks[i] < 60)
		{
			grade[i] = 'D';
		}
		else if (final_marks[i] < 50)
		{
			grade[i] = 'F';
		}
	}


	//array shown
	for (i = 0; i <= size; i++)
	{
		cout << "ROLL NUM : " << roll_num[i] << "      MID MARKS : " << mid_marks[i] << "      FINAL MARKS : " << final_marks[i] << "      CLASS : " << class_of_student[i] << "      GRADE : " << grade[i] << endl;
	}


	//copying in dummy array
	int dummy_roll_num[roll_num_size] = {};

	float dummy_mid_marks[mid_marks_size] = {};

	float dummy_final_marks[final_marks_size] = {};

	int dummy_class_of_student[class_size] = {};

	char dummy_grade[grade_size] = {};

	for (i = 0; i < 100; i++)
	{
		dummy_roll_num[i] = roll_num[i];
		dummy_mid_marks[i] = mid_marks[i];
		dummy_grade[i] = grade[i];
		dummy_final_marks[i] = final_marks[i];
		dummy_class_of_student[i] = class_of_student[i];
	}


	//menu
	while (option_selection == 'a' || option_selection == 'b' || option_selection == 'c' || option_selection == 'd' || option_selection == 'f' || option_selection == 'g' || option_selection == 'h'
		|| option_selection == 'i' || option_selection == 'j' || option_selection == 'k' || option_selection == 'l' || option_selection == 'm' || option_selection == 'n' || option_selection == 'o'
		|| option_selection == 'p' || option_selection == 'q' || option_selection == 'r' || option_selection == 's' || option_selection == 'e' || option_selection == 'E')
	{
		if (option_selection == 'e' || option_selection == 'E')
		{
			break;
		}
		else
		{
			cout << "*********************************************************************************" << endl;
			cout << "                                      MENU                                       " << endl;
			cout << "*********************************************************************************" << endl;
			cout << "Please choose an option" << endl;

			cout << "a. Sort and display all the records roll number wise in ascending order" << endl;
			cout << "b. Sort and display all the records roll number wise in descending order" << endl;
			cout << "c. Sort and display all the records in ascending order based on marks in Midterm" << endl;
			cout << "d. Sort and display all the records in descending order based on marks in Midterm" << endl;
			cout << "f. Sort and display all the records in ascending order based on marks in Final" << endl;
			cout << "g. Sort and display all the records in descending order based on marks in Final" << endl;
			cout << "h. Sort and display all the records in ascending order based on Grade" << endl;
			cout << "i. Sort and display all the records in descending order based on Grade" << endl;
			cout << "j. Add a new entry of student" << endl;
			cout << "k. Delete a student record based on his roll number" << endl;
			cout << "l. Display record of all the students greater than X marks in final exam (in descending order with respect to marks obtained in final exam)" << endl;
			cout << "m. Display record of all the students greater than X marks in final exam (in ascending order with respect to marks obtained in final exam)" << endl;
			cout << "n. Display record of all the students less than or equal to X marks in final exam (in descending order with respect to marks obtained in final exam)" << endl;
			cout << "o. Display record of all the students less than or equal to X marks in final exam (in ascending order with respect to marks obtained in final exam)" << endl;
			cout << "p. Display record of all the students greater than X Grade (in descending order with respect to Grade)" << endl;
			cout << "q. Display record of all the students greater than X Grade (in ascending order with respect to Grade)" << endl;
			cout << "r. Display record of all the students less than or equal to X Grade (in descending order with respect to Grade)" << endl;
			cout << "s. Display record of all the students less than or equal to X Grade (in ascending order with respect to Grade)" << endl << endl;
			cout << "Press e or E to exit" << endl;
			cin >> option_selection;
			if (option_selection != 'a' && option_selection != 'b' && option_selection != 'c' && option_selection != 'd' && option_selection != 'f' && option_selection != 'g' && option_selection != 'h'
				&& option_selection != 'i' && option_selection != 'j' && option_selection != 'k' && option_selection != 'l' && option_selection != 'm' && option_selection != 'n' && option_selection != 'o'
				&& option_selection != 'p' && option_selection != 'q' && option_selection != 'r' && option_selection != 's' && option_selection != 'e' && option_selection != 'E')
			{
				cout << "Please enter valid option" << endl;
			}
			else if (option_selection == 'a')
			{

				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_roll_num[i]>dummy_roll_num[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;

						}
					}
				}

				for (i = 0; i <= size; i++)
				{

					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}

			}
			else if (option_selection == 'b')
			{
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_roll_num[i] < dummy_roll_num[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;

						}
					}
				}
				for (i = 0; i <= size; i++)
				{

					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'c')
			{
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_mid_marks[i] > dummy_mid_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{

					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'd')
			{
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_mid_marks[i] < dummy_mid_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{

					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'f')
			{
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] > dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{

					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'g')
			{
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] < dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{

					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'h')
			{
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] > dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{

					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'i')
			{
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] < dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{

					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'j')
			{
				size++;
				do
				{

					cout << "Enter roll number" << endl;
					cin >> dummy_roll_num[size];
					do

					{
						count = 0;
						for (i = 0; i<size; i++)
						{
							if (dummy_roll_num[size] == dummy_roll_num[i])
							{
								count++;
							}
						}
						if (count>0)
						{
							cout << "Please try another roll num" << endl;
							cin >> dummy_roll_num[size];
						}
					} while (count != 0);

					if (dummy_roll_num[size] < 1)
					{
						cout << "Please enter a positive roll number" << endl;
						cin >> dummy_roll_num[size];
					}
					else if (dummy_roll_num[size] >2147483627)
					{
						cout << "Please enter a smaller roll number" << endl;
						cin >> dummy_roll_num[size];
					}
				} while (dummy_roll_num[size] < 1 || dummy_roll_num[size] > 2147483627);
				do
				{
					cout << "Enter marks obtained in mid term" << endl;
					cin >> dummy_mid_marks[size];
					if (dummy_mid_marks[size] < 0)
					{
						cout << "Please enter positive marks" << endl;
						cin >> dummy_mid_marks[size];
					}
					else if (dummy_mid_marks[size]>50)
					{
						cout << "Please enter marks less than 50" << endl;
						cin >> dummy_mid_marks[size];
					}
				} while (dummy_mid_marks[size]<0 || dummy_mid_marks[size]>50);
				do
				{
					cout << "Enter marks obtained in final term" << endl;
					cin >> dummy_final_marks[size];
					if (dummy_final_marks[size] < 0)
					{
						cout << "Please enter positive marks" << endl;
						cin >> dummy_final_marks[size];
					}
					else if (dummy_final_marks[size]>100)
					{
						cout << "Please enter marks less than 100" << endl;
						cin >> dummy_final_marks[size];
					}

				} while (dummy_final_marks[size]<0 || dummy_final_marks[size]>100);

				if (dummy_final_marks[size] >= 86 && dummy_final_marks[size] <= 100)
				{
					dummy_grade[size] = 'A';
				}
				else if (dummy_final_marks[size] >= 73 && dummy_final_marks[size] <= 85)
				{
					dummy_grade[size] = 'B';
				}
				else if (dummy_final_marks[size] >= 60 && dummy_final_marks[size] <= 72)
				{
					dummy_grade[size] = 'C';
				}
				else if (dummy_final_marks[size] >= 50 && dummy_final_marks[size] <= 59)
				{
					dummy_grade[size] = 'D';
				}
				else if (dummy_final_marks[size] < 50)
				{
					dummy_grade[size] = 'F';
				}
				do{
					cout << "Please enter class of student" << endl;
					cin >> dummy_class_of_student[size];
					if (dummy_class_of_student[size]<1 || dummy_class_of_student[size]>8)
					{
						cout << "Please enter class less than 8 and greater than 0" << endl;
						cin >> dummy_class_of_student[size];
					}
				} while (dummy_class_of_student[size]<1 || dummy_class_of_student[size]>8);


				for (i = 0; i <= size; i++)
				{
					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'k')
			{
				int j = 0;
				do
				{
					count = 0;
					cout << "Enter the roll num whose record you want to delete" << endl;
					cin >> delete_roll_num;
					for (i = 0; i <= size; i++)
					{
						if (delete_roll_num == dummy_roll_num[i])
						{
							count++;
						}
					}
					if (count == 0)
					{
						cout << "Roll number not available in record" << endl;
					}
					else if (count != 0)
					{
						for (i = 0; i <= size; i++)
						{
							if (dummy_roll_num[i] == delete_roll_num)
							{
								dummy_roll_num[i] = 0;
								for (k = 0; k<size; k++)
								{
									for (j = 0; j <= size; j++)
									{
										if (dummy_roll_num[j] == 0)
										{
											temp = dummy_roll_num[j + 1];
											dummy_roll_num[j + 1] = dummy_roll_num[j];
											dummy_roll_num[j] = temp;

											temp = dummy_class_of_student[j + 1];
											dummy_class_of_student[j + 1] = dummy_class_of_student[j];
											dummy_class_of_student[j] = temp;

											temp1 = dummy_mid_marks[j + 1];
											dummy_mid_marks[j + 1] = dummy_mid_marks[j];
											dummy_mid_marks[j] = temp1;

											temp1 = dummy_final_marks[j + 1];
											dummy_final_marks[j + 1] = dummy_final_marks[j];
											dummy_final_marks[j] = temp1;

											temp = dummy_grade[j + 1];
											dummy_grade[j + 1] = dummy_grade[j];
											dummy_grade[j] = temp;

										}
									}
								}

							}
						}
					}
				}

				while (count == 0);
				size--;
				for (i = 0; i <= size; i++)
				{
					cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
				}
			}
			else if (option_selection == 'l')
			{
				do
				{
					cout << "enter X marks" << endl;
					cin >> x_marks;
					if (x_marks<0 || x_marks>100)
					{
						cout << "please enter marks less than 100 and greater than 0" << endl;
					}
				} while (x_marks<0 || x_marks>100);
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] < dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{
					if (dummy_final_marks[i]>x_marks)
					{
						cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
					}

				}

			}
			else if (option_selection == 'm')
			{
				do
				{
					cout << "enter X marks" << endl;
					cin >> x_marks;
					if (x_marks<0 || x_marks>100)
					{
						cout << "please enter marks less than 100 and greater than 0" << endl;
					}
				} while (x_marks<0 || x_marks>100);
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] > dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{
					if (dummy_final_marks[i]>x_marks)
					{
						cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
					}

				}

			}
			else if (option_selection == 'n')
			{
				do
				{
					cout << "enter X marks" << endl;
					cin >> x_marks;
					if (x_marks<0 || x_marks>100)
					{
						cout << "please enter marks less than 100 and greater than 0" << endl;
					}
				} while (x_marks<0 || x_marks>100);
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] < dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{
					if (dummy_final_marks[i] <= x_marks)
					{
						cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
					}

				}

			}
			else if (option_selection == 'o')
			{
				do
				{
					cout << "enter X marks" << endl;
					cin >> x_marks;
					if (x_marks<0 || x_marks>100)
					{
						cout << "please enter marks less than 100 and greater than 0" << endl;
					}
				} while (x_marks<0 || x_marks>100);
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] > dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}
				for (i = 0; i <= size; i++)
				{
					if (dummy_final_marks[i] <= x_marks)
					{
						cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
					}

				}

			}
			else if (option_selection == 'p')
			{
				do
				{
					cout << "enter X grade" << endl;
					cin >> x_grade;
					if (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D')
					{
						cout << "please enter valid grade" << endl;
					}
				} while (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D');
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] < dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}

				if (x_grade == 'F')
				{
					marks = 49;
				}
				else if (x_grade == 'D')
				{
					marks = 59;
				}
				else if (x_grade == 'C')
				{
					marks = 73;
				}
				else if (x_grade == 'B')
				{
					marks = 85;
				}
				else if (x_grade == 'A')
				{
					marks = 100;
				}
				for (i = 0; i <= size; i++)
				{
					if (dummy_final_marks[i] > marks)
					{
						cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
					}

				}

			}
			else if (option_selection == 'q')
			{
				do
				{
					cout << "enter X grade" << endl;
					cin >> x_grade;
					if (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D')
					{
						cout << "please enter valid grade" << endl;
					}
				} while (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D');
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] > dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}

				if (x_grade == 'F')
				{
					marks = 49;
				}
				else if (x_grade == 'D')
				{
					marks = 59;
				}
				else if (x_grade == 'C')
				{
					marks = 73;
				}
				else if (x_grade == 'B')
				{
					marks = 85;
				}
				else if (x_grade == 'A')
				{
					marks = 100;
				}
				for (i = 0; i <= size; i++)
				{
					if (dummy_final_marks[i] > marks)
					{
						cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
					}

				}
			}
			else if (option_selection == 'r')
			{
				do
				{
					cout << "enter X grade" << endl;
					cin >> x_grade;
					if (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D')
					{
						cout << "please enter valid grade" << endl;
					}
				} while (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D');
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] < dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}

				if (x_grade == 'F')
				{
					marks = 49;
				}
				else if (x_grade == 'D')
				{
					marks = 59;
				}
				else if (x_grade == 'C')
				{
					marks = 72;
				}
				else if (x_grade == 'B')
				{
					marks = 85;
				}
				else if (x_grade == 'A')
				{
					marks = 100;
				}
				for (i = 0; i <= size; i++)
				{
					if (dummy_final_marks[i] <= marks)
					{
						cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
					}

				}



			}
			else if (option_selection == 's')
			{
				do
				{
					cout << "enter X grade" << endl;
					cin >> x_grade;
					if (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D')
					{
						cout << "please enter valid grade" << endl;
					}
				} while (x_grade != 'F'&&x_grade != 'A'&&x_grade != 'B'&&x_grade != 'C'&&x_grade != 'D');
				for (int j = 0; j <= size; j++)
				{
					for (i = 0; i <= size - 1; i++)
					{
						if (dummy_final_marks[i] > dummy_final_marks[i + 1])
						{
							temp = dummy_roll_num[i + 1];
							dummy_roll_num[i + 1] = dummy_roll_num[i];
							dummy_roll_num[i] = temp;

							temp = dummy_class_of_student[i + 1];
							dummy_class_of_student[i + 1] = dummy_class_of_student[i];
							dummy_class_of_student[i] = temp;

							temp1 = dummy_mid_marks[i + 1];
							dummy_mid_marks[i + 1] = dummy_mid_marks[i];
							dummy_mid_marks[i] = temp1;

							temp1 = dummy_final_marks[i + 1];
							dummy_final_marks[i + 1] = dummy_final_marks[i];
							dummy_final_marks[i] = temp1;

							temp = dummy_grade[i + 1];
							dummy_grade[i + 1] = dummy_grade[i];
							dummy_grade[i] = temp;
						}
					}
				}

				if (x_grade == 'F')
				{
					marks = 49;
				}
				else if (x_grade == 'D')
				{
					marks = 59;
				}
				else if (x_grade == 'C')
				{
					marks = 72;
				}
				else if (x_grade == 'B')
				{
					marks = 85;
				}
				else if (x_grade == 'A')
				{
					marks = 100;
				}
				for (i = 0; i <= size; i++)
				{
					if (dummy_final_marks[i] <= marks)
					{
						cout << "ROLL NUM : " << dummy_roll_num[i] << "      MID MARKS : " << dummy_mid_marks[i] << "      FINAL MARKS : " << dummy_final_marks[i] << "      CLASS : " << dummy_class_of_student[i] << "      GRADE : " << dummy_grade[i] << endl;
					}
				}
			}
		}
	}
}
