#include<iostream>//header file
using namespace std;
int main()//main
{
	cout << " _______________________________________________________________________________________ " << endl;//cout statement
	cout << "|                                       MENU                                            |" << endl;//cout statement
	cout << " _______________________________________________________________________________________ " << endl;//cout statement
	cout << "| press 1 to find greatest and smallest number among 10 numbers by user                 |" << endl;//cout statement
	cout << "| press 2 to display table from starting and ending values by user                      |" << endl;//cout statement
	cout << "| press 3 to show sum of even and odd numbers from 1 to till the number entered by user |" << endl;//cout statement
	cout << "| press 4 to print Fictorial of a number entered by user                                |" << endl;//cout statement
	cout << " _______________________________________________________________________________________ " << endl;//cout statement
	int n = 0;//initializing
	cout << "Enter task from 1 to 4 you want to execute : ";//cout statement
	cin >> n;//user enter n task to execute
	cout << endl;//endl statement for new line
	if (n == 1)//condition for task execution
	{
		int arr[10] = {};//initializing array

		cout << "enter 10 numbers " << endl;//cout statement
		for (int i = 0; i < 10; i++)//for loop check till i<10
		{
			cout << "enter number " << i + 1 << " : " << endl;//counter for 1 to 10 numbers
			cin >> arr[i];//user input numbers
		}

		for (int i = 0; i < 10; i++)//for loop check till i<10
		{
			if (arr[0] < arr[i])//if condition to check greater number
			{
				arr[0] = arr[i];
			}
		}
		cout << "greatest number among array is : " << arr[0] << endl;//cout statement

		for (int i = 0; i < 10; i++)//for loop check till i<10
		{
			if (arr[0] > arr[i])//if condition to check smallest number
			{
				arr[0] = arr[i];
			}
		}
		cout << "smallest number among array is : " << arr[0] << endl;//cout statement
	}

	else if (n == 2)//condition for task execution
	{
		//int num = 0;//initializing
		int now = 0;//initializing
		int start = 0;//initializing
		int ending = 0;//initializing
		int n = 0;
		cout << "enter table number which you want to see (not starting or ending numbers) : ";//cout statement
		cin >> n;//input by user
		cout << "enter starting number for table : ";//cout statement
		cin >> start;//input by user
		cout << "enter ending number for table : ";//cout statement
		cin >> ending;//input by user

		int i = 1;//declaring
		for (int j = start; j <=ending; j++)//for loop check till j<=10
		{
			now = start*j;//formula
			cout << start << " * " << j<<" = " << now << endl;//cout statement
			i++;//increment of 1 in 'i' variable
		}
			cout << endl;//for new line
	}

	else if (n == 3)//condition for task execution
	{
		int  n = 0;//initializing
		int sum = 0;//initializing
		cout << "Enter number for addition from 1 to that number : ";//cout statment
		cin >> n;//input by user
		for (int i = 1; i <= n; i++)//for loop check till i<=n
		{
			sum = sum + i;//formula
		}
		cout << sum << endl;//print sum
	}


	else if (n == 4)//condition for task execution
	{
		int n;//initializing
		float factorial = 1.0;//declaring

		cout << "Enter a positive integer for fictorial : ";//cout statement
		cin >> n;//input by user

		if (n < 0)//condition
			cout << "Error! Factorial of a negative number doesn't exist";//cout statement
		else {
			for (int i = 1; i <= n; ++i)//for loop check till i<=n
			{
				factorial *= i;//formula
			}
			cout << "Factorial of " << n << " = " << factorial<<endl;//cout statement
		}
	}

	else//condition for task execution
	{
		cout << "task is not available! " << endl;//cout statement for no task available of that number entered by user
	}

	system("pause");
	return 0;//returning 0
}