#include<iostream>
using namespace std;
int main()
{
	int i; int dummy_size = 50; int count = 0;
	char option_selection = { 'b' };
	const int size = 100;
	int roll_no[size] = { 10, 20, 30, 40, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 11, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 34, 35, 36, 37, 38, 39, 61, 71, 81, 62, 72, 73, 74, 90, 91 };
	float mids_marks[size] = { 22, 50, 40.5, 31, 42, 45, 50, 29.5, 32, 12, 8.5, 32, 21.5, 46, 8, 19.5, 16, 32, 44.5, 20, 21.5, 22, 23, 55, 55.5, 25, 14, 13.4, 15.5, 30, 31, 32.5, 33.6, 34, 35, 45, 50, 12, 8, 9, 10, 11, 23, 24, 25, 26, 12, 24.5, 34, 35 };
	float final_marks[size] = { 55.5, 56, 57.5, 58, 59, 88, 67, 54, 54, 33, 22, 89, 91, 67, 74, 46, 88.5, 12.4, 25.6, 55, 49, 77.5, 32, 14, 98, 87, 66.5, 23, 55.5, 66, 72.5, 65, 43.5, 66.6, 98.7, 12, 89, 64.7, 87.6, 67, 54, 33.5, 76.5, 65, 99, 13, 98.5, 76, 88, 67.5 };
	int class_of_student[size] = { 1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 6, 2, 7, 1, 7, 5, 3, 4, 8, 3, 4, 2, 1, 5, 3, 1, 3, 6, 7, 8, 5, 4, 3, 4, 2, 6, 7, 8, 2, 1, 6, 5, 4, 3, 8, 8, 2, 1, 4 };
	char grades[size] = {};
	int dummy_roll_no[size] = {};
	float dummy_mids_marks[size] = {};
	float dummy_final_marks[size] = {};
	int dummy_class_of_students[size] = {};
	char dummy_grades[size] = {};
	int temp = 0; float temp1 = 0; int deleted_roll_no; int x_marks = 0;
	for (i = 0; i < dummy_size; i++)
	{
		if (final_marks[i] < 50)
		{
			grades[i] = 'F';
		}
		else if (final_marks[i] >= 50 && final_marks[i] <= 59)
		{
			grades[i] = 'D';
		}
		else if (final_marks[i] >= 60 && final_marks[i] <= 72)
		{
			grades[i] = 'C';
		}
		else if (final_marks[i] >= 73 && final_marks[i] <= 85)
		{
			grades[i] = 'B';
		}
		else if (final_marks[i] >= 86)
		{
			grades[i] = 'A';
		}
	}
	for (i = 0; i < dummy_size; i++)
	{
		dummy_roll_no[i] = roll_no[i];
		dummy_mids_marks[i] = mids_marks[i];
		dummy_final_marks[i] = final_marks[i];
		dummy_class_of_students[i] = class_of_student[i];
		dummy_grades[i] = grades[i];
	}
	for (i = 0; i < dummy_size; i++)
	{
		cout << "roll no:" << dummy_roll_no[i] << "  " << "mids marks:" << dummy_mids_marks[i] << "  " << "final marks:" << dummy_final_marks[i] << "  " << "class:" << dummy_class_of_students[i] << "  " << "Grades:" << dummy_grades[i] << endl;
	}

	while (option_selection == 'a' || option_selection == 'b' || option_selection == 'c' || option_selection == 'd' || option_selection == 'z' || option_selection == 'f' || option_selection == 'g' || option_selection == 'h' || option_selection == 'i' || option_selection == 'j' || option_selection == 'k' || option_selection == 'l' || option_selection == 'm' || option_selection == 'n' || option_selection == 'o' || option_selection == 'p' || option_selection == 'q' || option_selection == 'r')
	{

		if (option_selection == 'e' || option_selection == 'E')
		{
			break;
		}
		else
		{
			cout << "*MENU**" << endl;
			cout << "a.Sort and display all the records roll number wise in ascending order:" << endl;
			cout << "b.Sort and display all the records roll number wise in descending order:" << endl;
			cout << "c.Sort and display all records in ascending order based on marks in Midterm:" << endl;
			cout << "d.Sort and display all records in descending order based on marks in Midterm: " << endl;
			cout << "z.Sort and display all records in ascending order based on marks in Final: " << endl;
			cout << "f.Sort and display all records in descending order based on marks in Final: " << endl;
			cout << "g.Sort and display all records in ascending order based on Grade: " << endl;
			cout << "h.Sort and display all records in descending order based on Grade: " << endl;
			cout << "i.Add a new entry of a student:" << endl;
			cout << "j.Delete a student record based on his roll number:" << endl;
			cout << "k.Display record of all the students greater than X marks in final exam (in descending order with respect to marks obtained in final exam). The value of X will be entered by the user: " << endl;
			cout << "l.Display record of all the students greater than X marks in final exam (in ascending order with respect to marks obtained in final exam). The value of X will be entered by the user:" << endl;
			cout << "m.Display record of all the students less than or equal to X marks in final exam (in descending order with respect to marks obtained in final exam). The value of X will be entered by the user:" << endl;
			cout << "n.Display record of all the students less than or equal to X marks in final exam (in ascending order with respect to marks obtained in final exam). The value of X will be entered by the user:" << endl;
			cout << "o.Display record of all the students greater than X grade (in descending order with respect to grade). The value of X (character) will be entered by the user:" << endl;
			cout << "p.Display record of all the students greater than X grade (in ascending order with respect to grade). The value of X (character) will be entered by the user:" << endl;
			cout << "q.Display record of all the students less than or equal to X grade (in descending order with respect to grade). The value of X (character) will be entered by the user:" << endl;
			cout << "r.Display record of all the students less than or equal to X grade (in ascending order with respect to grade). The value of X (character) will be entered by the user:" << endl;
			cout << "PRESS 'e'or 'E' for exit" << endl;
			cout << "enter option:"; cin >> option_selection;
			if (option_selection != 'e' && option_selection != 'E' && option_selection != 'a' && option_selection != 'b' && option_selection != 'c' && option_selection != 'd' && option_selection != 'z' && option_selection != 'f' && option_selection != 'g' && option_selection != 'h' && option_selection != 'i' && option_selection != 'j' && option_selection != 'k' && option_selection != 'l' && option_selection != 'm' && option_selection != 'n' && option_selection != 'o' && option_selection != 'p' && option_selection != 'q'&&option_selection == 'r')
			{
				cout << "Enter a valid option:" << endl;
				cin >> option_selection;
			}
		}
		if (option_selection == 'a')
		{
			for (int j = 0; j < dummy_size; j++)
			{
				for (i = 0; i<dummy_size - 1; i++)
				{
					if (dummy_roll_no[i] > dummy_roll_no[i + 1])
					{
						temp = dummy_roll_no[i + 1];
						dummy_roll_no[i + 1] = dummy_roll_no[i];
						dummy_roll_no[i] = temp;

						temp = dummy_class_of_students[i + 1];
						dummy_class_of_students[i + 1] = dummy_class_of_students[i];
						dummy_class_of_students[i] = temp;


						temp1 = dummy_mids_marks[i + 1];
						dummy_mids_marks[i + 1] = dummy_mids_marks[i];
						dummy_mids_marks[i] = temp1;

						temp1 = dummy_final_marks[i + 1];
						dummy_final_marks[i + 1] = dummy_final_marks[i];
						dummy_final_marks[i] = temp1;

						temp = dummy_grades[i + 1];
						dummy_grades[i + 1] = dummy_grades[i];
						dummy_grades[i] = temp;
					}
				}
			}
			for (i = 0; i < dummy_size; i++)
			{
				cout << "roll no:" << dummy_roll_no[i] << "  " << "mids marks:" << dummy_mids_marks[i] << "  " << "final marks:" << dummy_final_marks[i] << "  " << "class:" << dummy_class_of_students[i] << "  " << "Grades:" << dummy_grades[i] << endl;
			}
		}
		if (option_selection == 'b')
		{
			for (int j = 0; j < dummy_size; j++)
			{
				for (i = 0; i < dummy_size - 1; i++)
				{
					if (dummy_roll_no[i] < dummy_roll_no[i + 1])
					{
						temp = dummy_roll_no[i + 1];
						dummy_roll_no[i + 1] = dummy_roll_no[i];
						dummy_roll_no[i] = temp;

						temp = dummy_class_of_students[i + 1];
						dummy_class_of_students[i + 1] = dummy_class_of_students[i];
						dummy_class_of_students[i] = temp;

						temp1 = dummy_mids_marks[i + 1];
						dummy_mids_marks[i + 1] = dummy_mids_marks[i];
						dummy_mids_marks[i] = temp1;

						temp1 = dummy_final_marks[i + 1];
						dummy_final_marks[i + 1] = dummy_final_marks[i];
						dummy_final_marks[i] = temp1;

						temp = dummy_grades[i + 1];
						dummy_grades[i + 1] = dummy_grades[i];
						dummy_grades[i] = temp;
					}
				}
			}
			for (i = 0; i < dummy_size; i++)
			{
				cout << "roll no:" << dummy_roll_no[i] << "  " << "mids marks:" << dummy_mids_marks[i] << "  " << "final marks:" << dummy_final_marks[i] << "  " << "class:" << dummy_class_of_students[i] << "  " << "Grades:" << dummy_grades[i] << endl;
			}
		}
		else if (option_selection == 'c')
		{
			for (int j = 0; j < dummy_size; j++)
			{
				for (i = 0; i<dummy_size - 1; i++)
				{
					if (dummy_mids_marks[i] > dummy_mids_marks[i + 1])
					{
						temp1 = dummy_mids_marks[i + 1];
						dummy_mids_marks[i + 1] = dummy_mids_marks[i];
						dummy_mids_marks[i] = temp1;

						temp = dummy_class_of_students[i + 1];
						dummy_class_of_students[i + 1] = dummy_class_of_students[i];
						dummy_class_of_students[i] = temp;


						temp = dummy_roll_no[i + 1];
						dummy_roll_no[i + 1] = dummy_roll_no[i];
						dummy_roll_no[i] = temp;

						temp1 = dummy_final_marks[i + 1];
						dummy_final_marks[i + 1] = dummy_final_marks[i];
						dummy_final_marks[i] = temp1;

						temp = dummy_grades[i + 1];
						dummy_grades[i + 1] = dummy_grades[i];
						dummy_grades[i] = temp;


					}
				}
			}
			for (i = 0; i < dummy_size; i++)
			{
				cout << "roll no:" << dummy_roll_no[i] << "  " << "mids marks:" << dummy_mids_marks[i] << "  " << "final marks:" << dummy_final_marks[i] << "  " << "class:" << dummy_class_of_students[i] << "  " << "Grades:" << dummy_grades[i] << endl;
			}

		}

		else if (option_selection == 'd')
		{
			for (int j = 0; j < dummy_size; j++)
			{
				for (i = 0; i < dummy_size - 1; i++)
				{
					if (dummy_mids_marks[i] < dummy_mids_marks[i + 1])
					{
						temp1 = dummy_mids_marks[i + 1];
						dummy_mids_marks[i + 1] = dummy_mids_marks[i];
						dummy_mids_marks[i] = temp1;

						temp = dummy_class_of_students[i + 1];
						dummy_class_of_students[i + 1] = dummy_class_of_students[i];
						dummy_class_of_students[i] = temp;


						temp = dummy_roll_no[i + 1];
						dummy_roll_no[i + 1] = dummy_roll_no[i];
						dummy_roll_no[i] = temp;

						temp1 = dummy_final_marks[i + 1];
						dummy_final_marks[i + 1] = dummy_final_marks[i];
						dummy_final_marks[i] = temp1;

						temp = dummy_grades[i + 1];
						dummy_grades[i + 1] = dummy_grades[i];
						dummy_grades[i] = temp;


					}
				}
			}
			for (i = 0; i < dummy_size; i++)
			{
				cout << "roll no:" << dummy_roll_no[i] << "  " << "mids marks:" << dummy_mids_marks[i] << "  " << "final marks:" << dummy_final_marks[i] << "  " << "class:" << dummy_class_of_students[i] << "  " << "Grades:" << dummy_grades[i] << endl;
			}
		}
		else if (option_selection == 'z')
		{
			for (int j = 0; j < dummy_size; j++)
			{
				for (i = 0; i<dummy_size - 1; i++)
				{
					if (dummy_final_marks[i] > dummy_final_marks[i + 1])
					{
						temp1 = dummy_final_marks[i + 1];
						dummy_final_marks[i + 1] = dummy_final_marks[i];
						dummy_final_marks[i] = temp1;

						temp = dummy_class_of_students[i + 1];
						dummy_class_of_students[i + 1] = dummy_class_of_students[i];
						dummy_class_of_students[i] = temp;


						temp = dummy_roll_no[i + 1];
						dummy_roll_no[i + 1] = dummy_roll_no[i];
						dummy_roll_no[i] = temp;

						temp1 = dummy_mids_marks[i + 1];
						dummy_mids_marks[i + 1] = dummy_mids_marks[i];
						dummy_mids_marks[i] = temp1;

						temp = dummy_grades[i + 1];
						dummy_grades[i + 1] = dummy_grades[i];
						dummy_grades[i] = temp;


					}
				}
			}
			for (i = 0; i < dummy_size; i++)
			{
				cout << "roll no:" << dummy_roll_no[i] << "  " << "mids marks:" << dummy_mids_marks[i] << "  " << "final marks:" << dummy_final_marks[i] << "  " << "class:" << dummy_class_of_students[i] << "  " << "Grades:" << dummy_grades[i] << endl;
			}
		}
		else if (option_selection == 'f')
		{
			for (int j = 0; j < dummy_size; j++)
			{
				for (i = 0; i < dummy_size - 1; i++)
				{
					if (dummy_final_marks[i] < dummy_final_marks[i + 1])
					{
						temp1 = dummy_final_marks[i + 1];
						dummy_final_marks[i + 1] = dummy_final_marks[i];
						dummy_final_marks[i] = temp1;

						temp = dummy_class_of_students[i + 1];
						dummy_class_of_students[i + 1] = dummy_class_of_students[i];
						dummy_class_of_students[i] = temp;


						temp = dummy_roll_no[i + 1];
						dummy_roll_no[i + 1] = dummy_roll_no[i];
						dummy_roll_no[i] = temp;

						temp1 = dummy_mids_marks[i + 1];
						dummy_mids_marks[i + 1] = dummy_mids_marks[i];
						dummy_mids_marks[i] = temp1;

						temp = dummy_grades[i + 1];
						dummy_grades[i + 1] = dummy_grades[i];
						dummy_grades[i] = temp;


					}
				}
			}
			for (i = 0; i < dummy_size; i++)
			{
				cout << "roll no:" << dummy_roll_no[i] << "  " << "mids marks:" << dummy_mids_marks[i] << "  " << "final marks:" << dummy_final_marks[i] << "  " << "class:" << dummy_class_of_students[i] << "  " << "Grades:" << dummy_grades[i] << endl;
			}
		}
		else if (option_selection == 'g')
		{
			for (int j = 0; j < dummy_size; j++)
			{
				for (i = 0; i<dummy_size - 1; i++)
				{
					if (dummy_final_marks[i] > dummy_final_marks[i + 1])
					{
						temp1 = dummy_final_marks[i + 1];
						dummy_final_marks[i + 1] = dummy_final_marks[i];
						dummy_final_marks[i] = temp1;

						temp = dummy_class_of_students[i + 1];
						dummy_class_of_students[i + 1] = dummy_class_of_students[i];
						dummy_class_of_students[i] = temp;


						temp = dummy_roll_no[i + 1];
						dummy_roll_no[i + 1] = dummy_roll_no[i];
						dummy_roll_no[i] = temp;

						temp1 = dummy_mids_marks[i + 1];
						dummy_mids_marks[i + 1] = dummy_mids_marks[i];
						dummy_mids_marks[i] = temp1;

						temp = dummy_grades[i + 1];
						dummy_grades[i + 1] = dummy_grades[i];
						dummy_grades[i] = temp;


					}
				}
			}
			for (i = 0; i < dummy_size; i++)
			{
				cout << "roll no:" << dummy_roll_no[i] << "  " << "mids marks:" << dummy_mids_marks[i] << "  " << "final marks:" << dummy_final_marks[i] << "  " << "class:" << dummy_class_of_students[i] << "  " << "Grades:" << dummy_grades[i] << endl;
			}
		}
		else if (option_selection == 'h')
		{
			for (int j = 0; j < dummy_size; j++)
			{
				for (i = 0; i < dummy_size - 1; i++)
				{
					if (dummy_final_marks[i] < dummy_final_marks[i + 1])
					{
						temp1 = dummy_final_marks[i + 1];
						dummy_final_marks[i + 1] = dummy_final_marks[i];
						dummy_final_marks[i] = temp1;

						temp = dummy_class_of_students[i + 1];
						dummy_class_of_students[i + 1] = dummy_class_of_students[i];
						dummy_class_of_students[i] = temp;


						temp = dummy_roll_no[i + 1];
						dummy_roll_no[i + 1] = dummy_roll_no[i];
						dummy_roll_no[i] = temp;

						temp1 = dummy_mids_marks[i + 1];
						dummy_mids_marks[i + 1] = dummy_mids_marks[i];
						dummy_mids_marks[i] = temp1;

						temp = dummy_grades[i + 1];
						dummy_grades[i + 1] = dummy_grades[i];
						dummy_grades[i] = temp;


					}
				}
			}
		}
	}
}