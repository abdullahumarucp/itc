#include <iostream>
using namespace std;
int main()
{
	int arr[16] = { 1, 7, 9, 2,4,5,3,9, 21, 32, 2, 45 ,4,5,3,8};
	int arr2[8];

	for (int i = 0, j = 8; i < 8; i++, j++)
	{
		arr2[i] = arr[j];
	}

	for (int i = 0; i < 8; i++)
	{
		cout << arr[i] << "   ";
	}
	cout << endl;
	cout<< endl;

	for (int i = 0; i < 8; i++)
	{
		cout << arr2[i] << "   ";
	}
	cout << endl;

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if (arr[i] == arr2[j])
			{
				cout << "Common Number found: " << arr[i] << endl;
			}
		}
	}

	return 0;
}