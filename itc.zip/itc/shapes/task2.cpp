#include<iostream>
using namespace std;

int main()
{

	int k = 1;


	for (int i = 1; i <= 5; i++)
	{
		for (int j = 4; j >= i; j--)
		{
			cout << " ";
		}
		for (int l = 0; l < k; l = l + 2)
		{
			cout << "10";
		}
		cout << endl;
		k = k + 2;
	}
  int e=9;
  for(int a=1;a<=5;a=a++)
 {
    for(int b=0;b<e;b=b+2)
   {
    cout<<"10";  // printing asterisk character
   }
    cout<<endl;
    e=e-2;

      for(int c=0;c<a;c=c++)
     {
      cout<<" ";  // printing space here
     }

 }
 return 0;
}