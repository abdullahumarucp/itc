#include<iostream>
using namespace std;

int main()
{

	int k = 1;


	for (int i = 1; i <= 5; i++)
	{
		for (int j = 4; j >= i; j--)
		{
			cout << " ";  
		}
		for (int l = 0; l<k; l++)
		{
			cout << "*"; 
		}
		cout << endl;   
		k = k + 2;
	}
	return 0;

}