#include <iostream>
using namespace std;
int main()
{
	int i, j, rows;
	int k = 10;
	for (i = 1; i <= k; i++){
		for (j = 1; j <= i; j++){
			if (j == 1 || j == i || i == k)
			{
				cout << "*";
			}
			else{
				cout << " ";
			}
		}
		cout << endl;
	}
	return 0;
}