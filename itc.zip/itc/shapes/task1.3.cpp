#include<iostream>
using namespace std;

int main()
{
	int k = 9;

	

	for (int i = 1; i <= 5; i++)
	{
		for (int j = 0; j<k; j++)
		{
			cout << "*"; 
		}
		cout << endl;
		k = k - 2;

		for (int l = 0; l<i; l++)
		{
			cout << " "; 
		}

	}
	return 0;
}