#include<iostream>
using namespace std;
int main()
{
	for (int a = 1; a <= 10; a++)
	{
		cout << "*";
	}
	cout << endl;
	for (int b = 1; b <= 5; b++)
	{
		for (int c = 1; c <= 1; c++)
		{
			cout << "*";
		}
		for (int d = 1; d <= 8; d++)
		{
			cout << " ";
		}
		cout << "*" << endl;
	}
	for (int e = 1; e <= 10; e++)
	{
		cout << "*";
	}
	cout << endl;
	return 0;
}
