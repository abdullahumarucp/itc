#include <iostream>//header file
using namespace std;
int main() 
{
	int number;//initializing variable
	cout << "___________________________________________" << endl;//print statement
	cout << "|                MENU                     |" << endl;//print statement
	cout << "___________________________________________" << endl;//print statement
	cout << "| Press (1-6) to print respective output  |" << endl;//print statement
	cout << "___________________________________________" << endl;//print statement

	cout <<endl<<endl<< "task : ";//print statement
	cin >> number;//getting number from user
	if (number == 1)//condition for task
	{
		for (int i = 1; i < 5; i++)//for loop
		{
			for (int j = 1; j <= 10; j++)//for nested loop
			{
				cout << "*";//print statement
			}
			cout << endl;//newline statement
		}
	}
	else if (number == 2)//condition for task
	{
		for (int i = 1; i <= 5; i++)//for loop
		{
			for (int j = 1; j <= i; j++)//for nested loop
			{
				cout << "*";//print statement
			}
			cout << endl;//newline statement
		}
	}
	else if (number == 3)//condition for task
	{
		for (int i = 1; i <= 5; i++)//for loop
		{
			for (int j = i; j<5; j++)//for nested loop
			{
				cout << " ";//print space
			}
			
			for (int k = 1; k <= i; k++)//for nested loop
			{
				cout << "*";//print statement
			}
			
			cout << endl;//newline statement
		}
	}
	else if (number == 4)//condition for task
	{
		for (int i = 1; i <= 5; i++) //for loop
		{
			for (int j = 1; j <= 5 - i; j++)//for nested loop
			{
				cout << " ";//print space
			}
			for (int k = 1; k <= 2 * i - 1; k++)//for nested loop
			{
				cout << "*";//print statement
			}
			cout << endl;//newline statement
		}
	}
	else if (number == 5)//condition for task
	{
		for (int i = 1; i <= 5; i++)//for loop
		{
			for (int j = 5; j >= i; j--)//for nested loop
			{
				cout << " ";//print space
			}
			for (int k = 1; k <= i * 2 - 1; k++)//for nested loop
			{
				cout << i;//print statement
			}
			cout << endl;//newline statement
		}
	}
	else if (number == 6)//condition for task
	{
		for (int i = 0; i <= 4; i++)//for loop
		{
			for (int j = 5; j >= i; j--)//for nested loop
			{
				cout << " ";//print space
			}
			for (int h = i + 1; h > 1; h--)//for nested loop
			{
				cout << h;//print statement
			}
			for (int k = 0; k < i + 1; k++)//for nested loop
			{
				cout << k + 1;//print statement
			}
			cout << endl;//newline statement
		}
	}
	else//condition for task
	{
		cout << endl;//newline statement
		cout << "The entered task is invalid " << endl;//print statement
		cout << "...program finished with exit code 0" << endl << "Press ENTER to exit consoles...";//print statement
	}
	return 0;//end code
}