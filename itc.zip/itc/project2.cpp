#include<iostream>
using namespace std;
int main()
{
	int student_id[10] = {0};
	float cgpa[10] = { 0.0 };
	char initial[10] = { '\0' };
	int age[10] = { 0 };
	int absents[10] = { 0 };

	cout << "             Enter data of student " << endl;   
	cout << "enter student id :  ";
	cin >> student_id[0];

	cout << "Enter cpga :  ";
	cin >> cgpa[0];

	cout << "Enter initial character :  ";
	cin >> initial[0];

	cout << "Enter age of student :  ";
	cin >> age[0];

	cout << "Enter absents of student :  ";
	cin >> absents[0];
	int size = 1;

	char option = '\0';
	for (int i = 1; i < 10; i++)
	{
		
		cout << "Enter y|Y to continues entering data of student  or enter n|N to stop entering data of students :  ";
		cin >> option;
		if (option == 'y' || option =='Y')
		{
			size++;
			cout << "enter student id :  ";
			cin >> student_id[i];
			bool found = true;
			while (1)
			{
				if (found == 1)
				for (int j = 0; j < i; j++)
				{
					found = false;
					if (student_id[i] == student_id[j])
					{
						cout << "Please Use a Unique Id :"; cin >> student_id[i];
						found = true;
						break;
					}
				}
				else
					break;
			}

			cout << "Enter cpga :  ";
			cin >> cgpa[i];

			cout << "Enter initial charecter :  ";
			cin >> initial[i];

			cout << "Enter age of student :  ";
			cin >> age[i];

			cout << "Enter absents of student :  ";
			cin >> absents[i];
		}
		else if (option == 'n'||option=='N')
		{
			break;
		}
		else
		{
			cout << "option not avail " << endl;
		}
	}


	int  dummy_student_id[10] = { 0 };
	float dummy_cgpa[10] = { 0.0 };
	char dummy_initial[10] = { '\0' };
	int dummy_age[10] = { 0 };
	int dummy_absents[10] = { 0 };

	for (int i = 0; i < size; i++)
	{
		dummy_student_id[i] = student_id[i];
		dummy_cgpa[i] = cgpa[i];
		dummy_initial[i] = initial[i];
		dummy_age[i] = age[i];
		dummy_absents[i] = absents[i];
	}

	int choice = 0;
	cout << "_____________________________________" << endl;
	cout << "|                MENU               |" << endl;
	cout << "_____________________________________" << endl;
	cout << endl << endl;
	cout << "press 1 to Display data for all the enrolled students" << endl;
	cout << "press 2 to Display data of the student with the highest and lowest CGPA" << endl;
	cout << "press 3 to Display the sorted record of a student based on their CGPA in ascending order" << endl;
	cout << "press 4 to Display the details of the students whose absents are more than 20" << endl;
	cout << endl << endl << "Enter option from above menu : ";
	cin >> choice;
	if (choice == 1)
	{
		for (int i = 0; i < size; i++)
		{
			cout << "Student id		" << "CGPA		" << "Initials		" << "Age		"<<"Absent" << endl;
			cout << student_id[i] << "			" << cgpa[i] << "		" << initial[i] << "			" << age[i] << "		" << absents[i] << endl;
		}
	}
	else if (choice == 2)
	{
		float temp = 0.0;
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				if (dummy_cgpa[i] > dummy_cgpa[j])
				{
					temp = dummy_cgpa[i];
					dummy_cgpa[i] = dummy_cgpa[j];
					dummy_cgpa[j] = temp;
				}
			}
		}
		for (int i = 0; i < size; i++)
		{
			if (dummy_cgpa[0] == cgpa[i])
			{
				cout << "Largest's cpga of student data is : " << endl;
				cout << "Student id		" << "CGPA		" << "Initials		" << "Age		" << "Absent" << endl;
				cout << student_id[i] << "			" << cgpa[i] << "		" << initial[i] << "			" << age[i] << "		" << absents[i] << endl;
			}
		}
		temp = 0.0;
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				if (dummy_cgpa[i] < dummy_cgpa[j])
				{
					temp = dummy_cgpa[i];
					dummy_cgpa[i] = dummy_cgpa[j];
					dummy_cgpa[j] = temp;
				}
			}
		}
		for (int i = 0; i < size; i++)
		{
			cout << "Smallest's cpga of student data is : " << endl;
			if (dummy_cgpa[0] == cgpa[i])
			{
				cout << "Student id		" << "CGPA		" << "Initials		" << "Age		" << "Absent" << endl;
				cout << student_id[i] << "			" << cgpa[i] << "		" << initial[i] << "			" << age[i] << "		" << absents[i] << endl;
			}
		}
	}

	else if (choice == 3)
	{
		// using temp variable for swaping
		int temp_id = 0;
		float temp_cgpa = 0;
		char temp_initial = 0;
		int temp_age = 0;
		int temp_absents = 0;

		for (int i = 0; i < size - 1; i++)
		{
			for (int j = i + 1; j < size; j++)
			{
				if (dummy_cgpa[i] > dummy_cgpa[j])		// ascending order sorting
				{
					temp_id = dummy_student_id[i];
					temp_cgpa = dummy_cgpa[i];
					temp_initial = dummy_initial[i];
					temp_age = dummy_age[i];
					temp_absents = dummy_absents[i];

					dummy_student_id[i] = dummy_student_id[j];
					dummy_cgpa[i] = dummy_cgpa[j];
					dummy_initial[i] = dummy_initial[j];
					dummy_age[i] = dummy_age[j];
					dummy_absents[i] = dummy_absents[j];

					dummy_student_id[j] = temp_id;
					dummy_cgpa[j] = temp_cgpa;
					dummy_initial[j] = temp_initial;
					dummy_age[j] = temp_age;
					dummy_absents[j] = temp_absents;
				}
			}
		}

		cout << endl << "Displaying Data In Ascending Order to CGPA of Students " << endl;
		for (int i = 0; i < size; i++)
		{
			cout << "Student id		" << "CGPA		" << "Initials		" << "Age		" << "Absent" << endl;
			cout << dummy_student_id[i] << "			" << dummy_cgpa[i] << "		" << dummy_initial[i] << "			" << dummy_age[i] << "		" << dummy_absents[i] << endl;
		}
		
	}

	else if (choice == 4)
	{
		for (int i = 0; i < size; i++)
		{
			if (absents[i] > 20)
			{

				cout << "Student id		" << "CGPA		" << "Initials		" << "Age		" << "Absent" << endl;
				cout << dummy_student_id[i] << "			" << dummy_cgpa[i] << "		" << dummy_initial[i] << "			" << dummy_age[i] << "		" << dummy_absents[i] << endl;
			}
		}
	}
	else
	{
		cout << "option not available!" << endl;
	}
	system("pause");
	return 0;
}
